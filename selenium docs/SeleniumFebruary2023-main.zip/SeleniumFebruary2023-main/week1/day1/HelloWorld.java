package week1.day1;

public class HelloWorld {
public static void main(String[] args) {
	System.out.println("Balaji");
	// Data Type  Variable Name = value;
	int inputOne = 5;
	System.out.println(inputOne);
	Integer inputOne1 = 5;
	byte inputTwo = 127;
	short inputThree = -4567;
	long inputFour = 98876756456537l;
	
	float inputFive = 8977.234134f;
	double inputSix = 23452345.2349875283475;
	

	boolean inputSeven = true;
	boolean inputEight = false;
	
	char inputNine = 'a';
	
	String name = "Testleaf";
	System.out.println("Testleaf");
	System.out.println(name);
	
	
	
	
}
}
