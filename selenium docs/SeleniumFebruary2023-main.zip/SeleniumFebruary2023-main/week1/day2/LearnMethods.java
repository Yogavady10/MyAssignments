package week1.day2;

public class LearnMethods {
	public int a = 5;
	private int b = 6;
	int totalSum = 7;
	
	public void printName() {
		System.out.println("Testleaf");
	}
	
	private long getCCNumber() {
		long ccNumber = 4134567890431245L;
		return ccNumber;
	}
	
	int addTwoNumbers(int num1, int num2) {
		return num1+num2;
	}
	
	
	/*getText()
	getCurrentUrl()
	getTitle()
	sendKeys()
	moveToElement()*/
	
// Methods and variables
	/*accessModifier returnType methodName(arg) {
		
	}*/
	// Access Modifier
	// public,private,package/no modifier,protected
}
