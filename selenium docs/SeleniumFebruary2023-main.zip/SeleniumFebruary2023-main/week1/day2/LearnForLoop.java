package week1.day2;

public class LearnForLoop {
public static void main(String[] args) {
	for(int i = 1;i <= 10;i=i+1) {
		System.out.println(i);
	}
	/*i = 1; 1 <= 10 -> true; block; i -> 2
	i = 2; 2 <= 10 -> true; block; i -> 3;
	i = 9; 9 <= 10 -> true; block; i -> 10;
	i = 10; 10 <= 10 -> true; block; i -> 11;
	i = 11; 11 <= 10 -> false -> out of the loop
		*/	
		/*
		 * int num = 10; num % 2 != 0 4/2 -> 2 4%2 -> 0 / -> Q % -> R
		 */
}
}
