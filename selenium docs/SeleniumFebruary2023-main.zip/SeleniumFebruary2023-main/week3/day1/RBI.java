package week3.day1;

public class RBI {
	
	public void fixedDeposit() {
		System.out.println("12% interest rate");
	}

}
