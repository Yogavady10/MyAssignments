package week3.day1;

public class Vehicle {
	
	public void applyBrake() {
	   System.out.println("Brake applied");

	}
	
	public void soundHorn() {
		System.out.println("Horn!!");

	}
	


}
