package week3.day1;

public class Auto extends Vehicle{
    
	 public void onMeter() {
	    System.out.println("Turn meter");

	}
	 
	 
}
