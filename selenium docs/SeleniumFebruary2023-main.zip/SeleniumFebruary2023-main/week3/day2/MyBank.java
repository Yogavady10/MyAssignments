package week3.day2;

public class MyBank extends AxisBank{

	@Override
	public void withDrawLimit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void knowYourCustomer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cibilScore() {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		MyBank mb = new MyBank();
		mb.cibilScore();
		mb.knowYourCustomer();
		mb.withDrawLimit();
		mb.repoRate();
		
	}

	

}
