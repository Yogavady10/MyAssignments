package week3.day2;

public class SBIBank implements RBI{

	@Override
	public void withDrawLimit() {
		
		
	}
	
	public void knowYourCustomer() {
	
		
	}
	
	public void creditCard() {
		
	}

	@Override
	public void repoRate() {
		// TODO Auto-generated method stub
		
	}

}
