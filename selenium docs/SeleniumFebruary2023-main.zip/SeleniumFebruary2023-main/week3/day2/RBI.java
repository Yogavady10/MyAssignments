package week3.day2;

public interface RBI {
	
	public void repoRate();

	public void withDrawLimit();

	public void knowYourCustomer();
	
	
}
