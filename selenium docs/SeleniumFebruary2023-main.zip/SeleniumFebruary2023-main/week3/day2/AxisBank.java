package week3.day2;

public abstract class AxisBank implements RBI{
	
	@Override
	public void repoRate() {
		
	}
	
	public void fixedDeposit() {
		
	}
	 
	public abstract  void cibilScore();
	
	
}
