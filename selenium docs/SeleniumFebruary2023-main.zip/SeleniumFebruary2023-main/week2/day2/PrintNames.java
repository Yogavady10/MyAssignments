package week2.day2;

import java.util.Arrays;

public class PrintNames {

	public static void main(String[] args) {
		 String[] names={"Ranjith","Murali","Indhu","Deepa"};
		 //Arrays.sort(names);
		 for (int i = names.length-1; i >=0; i--) {
			System.out.println(names[i]);
		}

	}

}
